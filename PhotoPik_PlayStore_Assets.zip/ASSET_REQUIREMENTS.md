# Play Store Asset Requirements

This document outlines all the visual assets you need to prepare for your Play Store listing.

## Required Assets

### 1. App Icon
- **Size**: 512 x 512 pixels
- **Format**: PNG
- **Requirements**:
  - No transparency
  - Square format
  - High quality, sharp edges
  - Should look good at small sizes
  - Must not contain rounded corners (Play Store adds them automatically)

**Location**: Use one of the existing launcher icons from `android/app/src/main/res/mipmap-xxxhdpi/ic_launcher.png` as reference, or create a new 512x512 version.

### 2. Feature Graphic
- **Size**: 1024 x 500 pixels
- **Format**: PNG or JPG
- **Requirements**:
  - Horizontal banner
  - Should showcase your app's key features
  - Text should be readable
  - No rounded corners needed

**Design Tips**:
- Include app name prominently
- Show key features visually
- Use your app's color scheme
- Keep text minimal and readable

### 3. Screenshots

#### Phone Screenshots (Required)
- **Minimum**: 2 screenshots
- **Maximum**: 8 screenshots
- **Aspect Ratio**: 16:9 or 9:16 (portrait recommended for phone apps)
- **Format**: PNG or JPG
- **Recommended Sizes**:
  - 1080 x 1920 (9:16 portrait)
  - 1920 x 1080 (16:9 landscape)

**What to Include**:
1. Main camera interface
2. Photo editing/filter screen
3. Gallery view
4. Filter selection
5. Share functionality
6. Any other key features

#### Tablet Screenshots (Optional but Recommended)
- Same requirements as phone
- Show how app looks on larger screens

### 4. Promotional Graphics (Optional)

#### Promotional Banner
- **Size**: 180 x 120 pixels
- **Format**: PNG
- Used in Play Store promotions

#### TV Banner (if supporting Android TV)
- **Size**: 1280 x 720 pixels
- **Format**: PNG

## How to Create Screenshots

### Option 1: Use Flutter Screenshot Tools
```bash
# Install screenshot package
flutter pub add screenshot

# Or use device screenshot
# Take screenshots directly from your device/emulator
```

### Option 2: Use Android Studio
1. Open your app in Android Studio
2. Use the device emulator
3. Take screenshots using the emulator controls
4. Edit and enhance as needed

### Option 3: Use Physical Device
1. Run your app on a physical device
2. Take screenshots using device screenshot function
3. Transfer to computer
4. Edit and resize as needed

## Design Guidelines

### Best Practices:
- ✅ Show real app content, not mockups
- ✅ Use actual screenshots from your app
- ✅ Highlight key features
- ✅ Keep UI elements visible and clear
- ✅ Use consistent styling
- ✅ Show different screens/states

### What to Avoid:
- ❌ Blurry or low-quality images
- ❌ Too much text overlay
- ❌ Misleading screenshots
- ❌ Outdated UI (if you update the app)
- ❌ Screenshots that don't match current app version

## Asset Checklist

Before uploading to Play Console, ensure you have:

- [ ] App icon (512x512px PNG)
- [ ] Feature graphic (1024x500px PNG/JPG)
- [ ] At least 2 phone screenshots
- [ ] Up to 8 phone screenshots (recommended)
- [ ] Tablet screenshots (optional)
- [ ] All assets meet size requirements
- [ ] All assets are high quality

## Tools for Creating Assets

### Free Tools:
- **GIMP** - Image editing
- **Canva** - Graphic design templates
- **Figma** - Design tool
- **Photopea** - Online Photoshop alternative

### Paid Tools:
- **Adobe Photoshop** - Professional image editing
- **Adobe Illustrator** - Vector graphics
- **Sketch** - UI design

## Quick Reference

| Asset Type | Size | Format | Required |
|------------|------|--------|----------|
| App Icon | 512x512 | PNG | Yes |
| Feature Graphic | 1024x500 | PNG/JPG | Yes |
| Phone Screenshot | 1080x1920+ | PNG/JPG | Yes (min 2) |
| Tablet Screenshot | 1080x1920+ | PNG/JPG | Optional |

## Next Steps

1. Create or gather all required assets
2. Ensure all assets meet size and format requirements
3. Test how assets look in Play Console preview
4. Upload to Play Console when creating your store listing

