# Build Instructions for Play Store

This guide explains how to build the PhotoPik app bundle on your development machine.

## Prerequisites

1. **Flutter SDK** installed and configured
2. **Java Development Kit (JDK)** - Required for Android builds
3. **Android Studio** (optional but recommended)
4. **Signing keystore** - Generated using keytool

## Step-by-Step Build Process

### 1. Verify Flutter Setup

```bash
flutter doctor
```

Ensure all required components are installed (Android toolchain, etc.)

### 2. Get Dependencies

```bash
cd /path/to/photopik
flutter pub get
```

### 3. Set Up Signing (First Time Only)

#### Generate Keystore:
```bash
keytool -genkey -v -keystore android/keystore.jks -keyalg RSA -keysize 2048 -validity 10000 -alias upload
```

You'll be prompted for:
- Keystore password
- Key password
- Your name, organization, etc.

**IMPORTANT**: Save the passwords securely!

#### Configure Signing:
1. Copy the template:
   ```bash
   cp android/key.properties.template android/key.properties
   ```

2. Edit `android/key.properties`:
   ```
   storePassword=YOUR_KEYSTORE_PASSWORD
   keyPassword=YOUR_KEY_PASSWORD
   keyAlias=upload
   storeFile=../keystore.jks
   ```

### 4. Update Package Name (If Needed)

⚠️ **IMPORTANT**: Change the package name from `com.photopik.app` to your unique package name before first release!

Edit `android/app/build.gradle.kts`:
```kotlin
applicationId = "com.yourcompany.photopik"  // Change this!
namespace = "com.yourcompany.photopik"      // Change this!
```

Also update `MainActivity.kt` package name and move the directory accordingly.

### 5. Update Version (For Each Release)

Edit `pubspec.yaml`:
```yaml
version: 1.0.1+2  # Increment version name and build number
```

- Version name (1.0.1): Shown to users
- Build number (+2): Must increment for each release

### 6. Clean Previous Builds (Optional but Recommended)

```bash
flutter clean
flutter pub get
```

### 7. Build the App Bundle

```bash
flutter build appbundle --release
```

This will create: `build/app/outputs/bundle/release/app-release.aab`

### 8. Verify the Build

Check the file size and location:
```bash
# Windows
dir build\app\outputs\bundle\release\app-release.aab

# Linux/Mac
ls -lh build/app/outputs/bundle/release/app-release.aab
```

The file should be several MB in size (typically 10-50MB depending on assets).

### 9. Test the Build (Optional)

You can test the release build before uploading:

```bash
# Build APK for testing
flutter build apk --release

# Install on connected device
flutter install --release
```

## Troubleshooting

### Build Fails with Signing Error

**Problem**: `key.properties` not found or incorrect

**Solution**:
- Ensure `android/key.properties` exists
- Check that paths in `key.properties` are correct
- Verify keystore file exists at specified path

### Build Fails with Package Name Error

**Problem**: Package name conflicts or invalid

**Solution**:
- Ensure package name follows reverse domain format: `com.company.appname`
- Check that all package references are updated consistently
- Verify MainActivity.kt package matches build.gradle.kts

### Build Fails with Version Error

**Problem**: Version code already used

**Solution**:
- Increment build number in `pubspec.yaml`
- Clean and rebuild: `flutter clean && flutter build appbundle --release`

### Out of Memory Error

**Problem**: Build process runs out of memory

**Solution**:
- Increase Gradle memory in `android/gradle.properties`:
  ```
  org.gradle.jvmargs=-Xmx4G -XX:MaxMetaspaceSize=2G
  ```

## Build Commands Reference

```bash
# Clean build
flutter clean

# Get dependencies
flutter pub get

# Build app bundle (for Play Store)
flutter build appbundle --release

# Build APK (for testing)
flutter build apk --release

# Build with size analysis
flutter build appbundle --release --analyze-size

# Check for issues
flutter analyze
```

## File Locations

After building, you'll find:

- **App Bundle**: `build/app/outputs/bundle/release/app-release.aab`
- **APK** (if built): `build/app/outputs/flutter-apk/app-release.apk`
- **Mapping file** (for crash reports): `build/app/outputs/mapping/release/mapping.txt`

## Next Steps

Once you have `app-release.aab`:

1. Transfer it to your Play Console laptop
2. Upload to Google Play Console
3. Complete store listing
4. Submit for review

See `PLAYSTORE_DEPLOYMENT.md` for complete deployment instructions.

