# PhotoPik - Play Store Deployment Package

This package contains everything you need to deploy PhotoPik to the Google Play Store.

## 📦 Package Contents

### 1. App Configuration Files
- `android/` - Complete Android configuration
- `pubspec.yaml` - App version and metadata
- `PLAYSTORE_DEPLOYMENT.md` - Full deployment guide

### 2. Signing Setup
- `android/key.properties.template` - Template for signing configuration
- `setup_playstore.ps1` - Automated setup script

### 3. App Metadata
- `APP_METADATA.txt` - Ready-to-use app descriptions and metadata

### 4. Asset Requirements
- `ASSET_REQUIREMENTS.md` - Detailed requirements for icons and screenshots
- `asset_templates/` - Templates and specifications

## 🚀 Quick Start

### Step 1: Set Up Signing (On Your Development Machine)

1. Generate keystore:
   ```bash
   keytool -genkey -v -keystore android/keystore.jks -keyalg RSA -keysize 2048 -validity 10000 -alias upload
   ```

2. Configure signing:
   - Copy `android/key.properties.template` to `android/key.properties`
   - Fill in your keystore information

### Step 2: Build App Bundle

On your development machine with Flutter installed:

```bash
flutter pub get
flutter build appbundle --release
```

The output will be: `build/app/outputs/bundle/release/app-release.aab`

### Step 3: Prepare Assets

See `ASSET_REQUIREMENTS.md` for detailed requirements. You'll need:
- App icon (512x512px)
- Feature graphic (1024x500px)
- Screenshots (at least 2, up to 8)

### Step 4: Upload to Play Console

1. Go to [Google Play Console](https://play.google.com/console)
2. Create new app or select existing
3. Upload `app-release.aab` file
4. Complete store listing with assets
5. Submit for review

## 📋 Important Notes

⚠️ **Package Name**: Currently set to `com.photopik.app`. Change this to your unique package name before first release!

⚠️ **Version**: Current version is `1.0.0+1`. Increment build number for each release.

⚠️ **Signing**: Keep your keystore file and passwords secure. You'll need them for all future updates.

## 📚 Full Documentation

See `PLAYSTORE_DEPLOYMENT.md` for complete step-by-step instructions.

